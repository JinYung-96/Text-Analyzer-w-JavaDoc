/*Author Name: Angelo Jin Kaviany
 *Date: 10/18/2020 
 *Program Name: Kaviany_Text_Analyzer
 *Purpose: Test*/
package Kaviany;
public class test_file {

	public int countLetter(String letter) {
		int count = 0;
		for(int i = 0; i < letter.length(); i++) {
			if(letter.charAt(i) == 't' || letter.charAt(i) == 'T') {
				count++;
			}
		}
		return count;
	}
	
	public int countWord(String word) {
		int count = 0;
		for(int i = 0; i < word.length(); i++) {
			if(word.length() > 1) {
				count++;
			}
		}
		return count;
	}
}
