/*Author Name: Angelo Jin Kaviany
 *Date: 10/18/2020 
 *Program Name: Kaviany_Text_Analyzer
 *Purpose: Test*/
package Kaviany;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class word_test {

	@Test
	public void testWord() {
		test_file test = new test_file();
		int output = test.countLetter("Titanic");
		assertEquals(2, output);
	}
	
	@Test
	public void testLetter() {
		test_file test1 = new test_file();
		int output = test1.countWord("McBeth");
		assertEquals(6, output);
	}

}
