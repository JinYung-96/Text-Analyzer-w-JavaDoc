/*Author Name: Angelo Jin Kaviany
 *Date: 10/18/2020 
 *Program Name: Kaviany_Text_Analyzer
 *Purpose: Read in a file and output the word frequency while displaying the
 *top 20 most used words and their counts.*/
package Kaviany;
import java.io.*;
import java.util.*;
import java.util.Map.*;

/**
 * Words are delivered by read file and counted through a while loop.
 * Counts are recorded and stored within hashmap.
 * Returned by ordered pairs.
 * @author Jin
 *
 */
public class kaviany_text_analyzer {

	public static void main(String[] args) throws Exception{
		
		//Creates hashmap for the words and their count as integers
		HashMap<String, Integer> words = new HashMap<String, Integer>();
		wordCount("ReadMe.txt", words);
		//Treemap to start sorting the words by their linked values
		TreeMap<String, Integer> sorted = new TreeMap<>(words);
		Set<Entry<String, Integer>> entries = sorted.entrySet();
		//Comparing  counts
		Comparator<Entry<String, Integer>> countCompare = new Comparator<Entry<String, Integer>>(){
			
			public int compare(Entry<String, Integer> newInt1, Entry<String, Integer> newInt2) {
				Integer int1 = newInt1.getValue();
				Integer int2 = newInt2.getValue();
				return int2.compareTo(int1);
				}
		};		
		List<Entry<String, Integer>> listedObjects = new ArrayList<Entry<String, Integer>>(entries);
		Collections.sort(listedObjects, countCompare);
		LinkedHashMap<String, Integer> sortFromObject = new LinkedHashMap<String, Integer>(listedObjects.size());
		
		for(Entry<String, Integer> object : listedObjects) {
			sortFromObject.put(object.getKey(), object.getValue());
			}
		//Set out ordered pairs
		Set<Entry<String, Integer>> sortedByObjectCounts = sortFromObject.entrySet();
		
		for(Entry<String, Integer> mapping : sortedByObjectCounts) {
			System.out.println("(" + mapping.getKey() + "," + mapping.getValue()+ ")");
			}
	
	}
	
	
	/**
	 * Helper method to make counts of all words once finished closes file
	 * @param fileName
	 * @param words
	 * @return count
	 * @throws Exception 
	 */
	static void wordCount(String fileName, Map<String, Integer > words)throws Exception{
		Scanner file = new Scanner(new File(fileName));
		while (file.hasNext()) {
			String word = file.next();
			Integer count = words.get(word);
			if (count != null) 
				count++;
			else
				count = 1;
			words.put(word, count);
		}
		file.close();
	}

	
}
